---
name: notion-issue-tracker
description: This skill should be used when the user wants to create issues, bug reports, feature requests, or reviews in a Notion database. It analyzes text or images to extract issue information and automatically creates entries in Notion. Trigger phrases include "add to notion", "create issue", "log this bug", "feature request", or when sharing screenshots/images of bugs or feedback.
---

# Notion Issue Tracker

## Overview

This skill enables automatic creation of issues, bugs, feature requests, and reviews in a Notion database. It analyzes user input (text or images) to determine the issue type, priority, and creates structured entries in Notion.

## Setup Requirements

Before using this skill, ensure the following environment variables are configured:

```bash
# Required
NOTION_API_KEY=secret_xxxxx        # Notion Integration Token

# One of these (depending on usage)
NOTION_DATABASE_ID=xxxxx           # Existing database ID (for adding issues)
NOTION_PAGE_ID=xxxxx               # Parent page ID (for creating new database)
```

To obtain these values:
1. Create a Notion Integration at https://www.notion.so/my-integrations
2. Copy the Internal Integration Token as NOTION_API_KEY
3. Share the target database/page with the integration
4. Copy the database/page ID from the URL

## Database Schema

The skill uses the following database structure:

| Property | Type | Values |
|----------|------|--------|
| Title | title | Issue title |
| Type | select | Bug, Feature, Review |
| Description | rich_text | Detailed description |
| Priority | select | High, Medium, Low |
| Status | select | Todo, In Progress, Done |
| Created | date | Auto-filled creation date |

## Workflow

### 1. Analyze User Input

When the user provides input:

**For Text Input:**
- Extract the main issue/request
- Determine Type (Bug/Feature/Review) from context
- Assess Priority based on urgency indicators

**For Image Input (Screenshots, etc.):**
- Analyze the image content using vision capabilities
- Extract error messages, UI issues, or feedback
- Convert visual information to structured text description
- Note: Images cannot be directly uploaded to Notion; the analyzed content becomes the Description

### 2. Confirm with User

Before creating the issue, confirm the extracted information:

```
Issue to create:
- Title: [extracted title]
- Type: [Bug/Feature/Review]
- Priority: [High/Medium/Low]
- Description: [extracted description]

Proceed with creation?
```

### 3. Create Notion Entry

Execute the appropriate script based on the situation:

**To add issue to existing database:**
```bash
python3 scripts/add_issue.py \
  --title "Issue title" \
  --type "Bug" \
  --description "Description text" \
  --priority "High"
```

**To create new database first (one-time setup):**
```bash
python3 scripts/create_database.py
```

## Type Detection Guidelines

| Keywords/Context | Type |
|-----------------|------|
| error, crash, broken, not working, fix | Bug |
| add, implement, want, could you, would be nice | Feature |
| feedback, review, opinion, suggestion, improvement | Review |

## Priority Detection Guidelines

| Indicators | Priority |
|------------|----------|
| urgent, critical, blocking, ASAP, production | High |
| should, important, needed, soon | Medium |
| nice to have, when possible, minor, cosmetic | Low |

## Scripts

### scripts/add_issue.py
Adds a new issue to an existing Notion database.

### scripts/create_database.py
Creates a new Issue Tracker database in Notion with the proper schema.

## Limitations

- **No direct image upload**: Notion API does not support direct file uploads. Images are analyzed and converted to text descriptions.
- **External image URLs only**: If image attachment is needed, the image must first be uploaded to an external service (e.g., Imgur, S3) and the URL can be added to the description.
