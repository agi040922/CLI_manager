#!/usr/bin/env python3
"""
Add an issue to an existing Notion database.

Usage:
    python3 add_issue.py --title "Bug title" --type "Bug" --description "Description" --priority "High"

Environment Variables Required:
    NOTION_API_KEY: Notion Integration Token
    NOTION_DATABASE_ID: Target database ID
"""

import argparse
import os
import sys
from datetime import datetime

try:
    import requests
except ImportError:
    print("Error: requests library not installed. Run: pip install requests")
    sys.exit(1)


def get_env_var(name: str) -> str:
    """Get required environment variable or exit with error."""
    value = os.environ.get(name)
    if not value:
        print(f"Error: {name} environment variable is not set")
        sys.exit(1)
    return value


def create_issue(
    title: str,
    issue_type: str,
    description: str,
    priority: str,
    status: str = "Todo"
) -> dict:
    """Create a new issue in the Notion database."""

    api_key = get_env_var("NOTION_API_KEY")
    database_id = get_env_var("NOTION_DATABASE_ID")

    url = "https://api.notion.com/v1/pages"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "Notion-Version": "2022-06-28"
    }

    # Validate inputs
    valid_types = ["Bug", "Feature", "Review"]
    valid_priorities = ["High", "Medium", "Low"]
    valid_statuses = ["Todo", "In Progress", "Done"]

    if issue_type not in valid_types:
        print(f"Warning: Invalid type '{issue_type}'. Using 'Bug' as default.")
        issue_type = "Bug"

    if priority not in valid_priorities:
        print(f"Warning: Invalid priority '{priority}'. Using 'Medium' as default.")
        priority = "Medium"

    if status not in valid_statuses:
        print(f"Warning: Invalid status '{status}'. Using 'Todo' as default.")
        status = "Todo"

    payload = {
        "parent": {
            "type": "database_id",
            "database_id": database_id
        },
        "properties": {
            "Title": {
                "title": [
                    {
                        "type": "text",
                        "text": {
                            "content": title
                        }
                    }
                ]
            },
            "Type": {
                "select": {
                    "name": issue_type
                }
            },
            "Description": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": description[:2000]  # Notion limit
                        }
                    }
                ]
            },
            "Priority": {
                "select": {
                    "name": priority
                }
            },
            "Status": {
                "select": {
                    "name": status
                }
            },
            "Created": {
                "date": {
                    "start": datetime.now().isoformat()
                }
            }
        }
    }

    response = requests.post(url, headers=headers, json=payload)

    if response.status_code == 200:
        result = response.json()
        print(f"Issue created successfully!")
        print(f"URL: {result.get('url', 'N/A')}")
        return result
    else:
        print(f"Error creating issue: {response.status_code}")
        print(response.text)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Add an issue to Notion database")
    parser.add_argument("--title", required=True, help="Issue title")
    parser.add_argument("--type", required=True, choices=["Bug", "Feature", "Review"],
                        help="Issue type")
    parser.add_argument("--description", required=True, help="Issue description")
    parser.add_argument("--priority", required=True, choices=["High", "Medium", "Low"],
                        help="Issue priority")
    parser.add_argument("--status", default="Todo", choices=["Todo", "In Progress", "Done"],
                        help="Issue status (default: Todo)")

    args = parser.parse_args()

    create_issue(
        title=args.title,
        issue_type=args.type,
        description=args.description,
        priority=args.priority,
        status=args.status
    )


if __name__ == "__main__":
    main()
