#!/usr/bin/env python3
"""
Create a new Issue Tracker database in Notion.

Usage:
    python3 create_database.py [--name "Database Name"]

Environment Variables Required:
    NOTION_API_KEY: Notion Integration Token
    NOTION_PAGE_ID: Parent page ID where database will be created
"""

import argparse
import os
import sys

try:
    import requests
except ImportError:
    print("Error: requests library not installed. Run: pip install requests")
    sys.exit(1)


def get_env_var(name: str) -> str:
    """Get required environment variable or exit with error."""
    value = os.environ.get(name)
    if not value:
        print(f"Error: {name} environment variable is not set")
        sys.exit(1)
    return value


def create_database(name: str = "Issue Tracker") -> dict:
    """Create a new Issue Tracker database in Notion."""

    api_key = get_env_var("NOTION_API_KEY")
    page_id = get_env_var("NOTION_PAGE_ID")

    url = "https://api.notion.com/v1/databases"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "Notion-Version": "2022-06-28"
    }

    payload = {
        "parent": {
            "type": "page_id",
            "page_id": page_id
        },
        "title": [
            {
                "type": "text",
                "text": {
                    "content": name
                }
            }
        ],
        "properties": {
            "Title": {
                "title": {}
            },
            "Type": {
                "select": {
                    "options": [
                        {"name": "Bug", "color": "red"},
                        {"name": "Feature", "color": "blue"},
                        {"name": "Review", "color": "green"}
                    ]
                }
            },
            "Description": {
                "rich_text": {}
            },
            "Priority": {
                "select": {
                    "options": [
                        {"name": "High", "color": "red"},
                        {"name": "Medium", "color": "yellow"},
                        {"name": "Low", "color": "gray"}
                    ]
                }
            },
            "Status": {
                "select": {
                    "options": [
                        {"name": "Todo", "color": "default"},
                        {"name": "In Progress", "color": "blue"},
                        {"name": "Done", "color": "green"}
                    ]
                }
            },
            "Created": {
                "date": {}
            }
        }
    }

    response = requests.post(url, headers=headers, json=payload)

    if response.status_code == 200:
        result = response.json()
        database_id = result.get("id", "")

        print(f"Database created successfully!")
        print(f"Database ID: {database_id}")
        print(f"URL: {result.get('url', 'N/A')}")
        print(f"\nNext step: Set NOTION_DATABASE_ID={database_id}")

        return result
    else:
        print(f"Error creating database: {response.status_code}")
        print(response.text)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Create Issue Tracker database in Notion")
    parser.add_argument("--name", default="Issue Tracker",
                        help="Database name (default: Issue Tracker)")

    args = parser.parse_args()

    create_database(name=args.name)


if __name__ == "__main__":
    main()
