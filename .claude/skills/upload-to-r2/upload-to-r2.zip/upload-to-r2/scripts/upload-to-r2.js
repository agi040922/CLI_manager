#!/usr/bin/env node

import { createReadStream, statSync, readFileSync, existsSync } from 'fs';
import { createHmac, createHash } from 'crypto';
import https from 'https';
import { basename, join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Validate environment variables
function validateEnv() {
  const required = ['R2_ACCOUNT_ID', 'R2_ACCESS_KEY_ID', 'R2_SECRET_ACCESS_KEY', 'R2_BUCKET_NAME'];
  const missing = required.filter(key => !process.env[key]);

  if (missing.length > 0) {
    console.error('❌ Missing required environment variables:');
    missing.forEach(key => console.error(`   - ${key}`));
    console.error('\nPlease set these variables in your shell:');
    console.error('export R2_ACCOUNT_ID="your-account-id"');
    console.error('export R2_ACCESS_KEY_ID="your-access-key-id"');
    console.error('export R2_SECRET_ACCESS_KEY="your-secret-access-key"');
    console.error('export R2_BUCKET_NAME="your-bucket-name"');
    process.exit(1);
  }
}

// Get version from package.json or command line argument
function getVersion() {
  // Check if version provided as CLI argument
  const versionArg = process.argv[2];
  if (versionArg) {
    console.log(`Using version from argument: ${versionArg}`);
    return versionArg;
  }

  // Auto-detect from package.json
  const projectRoot = join(__dirname, '../../../');
  const packageJsonPath = join(projectRoot, 'package.json');

  if (!existsSync(packageJsonPath)) {
    console.error('❌ package.json not found. Please provide version as argument:');
    console.error('   node scripts/upload-to-r2.js 1.1.1');
    process.exit(1);
  }

  const packageJson = JSON.parse(readFileSync(packageJsonPath, 'utf8'));
  console.log(`Auto-detected version from package.json: ${packageJson.version}`);
  return packageJson.version;
}

// R2 Configuration from environment variables
const config = {
  accountId: process.env.R2_ACCOUNT_ID,
  bucketName: process.env.R2_BUCKET_NAME,
  accessKeyId: process.env.R2_ACCESS_KEY_ID,
  secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
  region: 'auto',
};

// AWS Signature V4 helpers
function hmac(key, string) {
  return createHmac('sha256', key).update(string, 'utf8').digest();
}

function hash(string) {
  return createHash('sha256').update(string, 'utf8').digest('hex');
}

function getSignatureKey(key, dateStamp, regionName, serviceName) {
  const kDate = hmac('AWS4' + key, dateStamp);
  const kRegion = hmac(kDate, regionName);
  const kService = hmac(kRegion, serviceName);
  const kSigning = hmac(kService, 'aws4_request');
  return kSigning;
}

async function uploadFile(filePath, config) {
  const fileName = basename(filePath);
  const stats = statSync(filePath);
  const fileSize = stats.size;

  console.log(`\nUploading ${fileName} (${(fileSize / 1024 / 1024).toFixed(2)} MB)...`);

  // AWS Signature V4 components
  const service = 's3';
  const host = `${config.accountId}.r2.cloudflarestorage.com`;
  const endpoint = `https://${host}`;
  const method = 'PUT';
  const objectPath = `/${config.bucketName}/${fileName}`;

  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, '');
  const dateStamp = amzDate.substring(0, 8);

  // Read file and calculate hash
  const fileStream = createReadStream(filePath);
  const chunks = [];
  for await (const chunk of fileStream) {
    chunks.push(chunk);
  }
  const fileBuffer = Buffer.concat(chunks);
  const payloadHash = hash(fileBuffer);

  // Create canonical request
  const canonicalUri = objectPath;
  const canonicalQuerystring = '';
  const canonicalHeaders = `host:${host}\nx-amz-content-sha256:${payloadHash}\nx-amz-date:${amzDate}\n`;
  const signedHeaders = 'host;x-amz-content-sha256;x-amz-date';
  const canonicalRequest = `${method}\n${canonicalUri}\n${canonicalQuerystring}\n${canonicalHeaders}\n${signedHeaders}\n${payloadHash}`;

  // Create string to sign
  const algorithm = 'AWS4-HMAC-SHA256';
  const credentialScope = `${dateStamp}/${config.region}/${service}/aws4_request`;
  const stringToSign = `${algorithm}\n${amzDate}\n${credentialScope}\n${hash(canonicalRequest)}`;

  // Calculate signature
  const signingKey = getSignatureKey(config.secretAccessKey, dateStamp, config.region, service);
  const signature = hmac(signingKey, stringToSign).toString('hex');

  // Create authorization header
  const authorizationHeader = `${algorithm} Credential=${config.accessKeyId}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

  // Upload file
  return new Promise((resolve, reject) => {
    const options = {
      hostname: host,
      port: 443,
      path: objectPath,
      method: method,
      headers: {
        'Host': host,
        'x-amz-date': amzDate,
        'x-amz-content-sha256': payloadHash,
        'Authorization': authorizationHeader,
        'Content-Type': 'application/octet-stream',
        'Content-Length': fileSize,
      },
    };

    const req = https.request(options, (res) => {
      let responseBody = '';

      res.on('data', (chunk) => {
        responseBody += chunk;
      });

      res.on('end', () => {
        if (res.statusCode === 200) {
          console.log(`✅ ${fileName} uploaded successfully!`);
          console.log(`   URL: ${endpoint}${objectPath}`);
          resolve();
        } else {
          console.error(`❌ Upload failed with status ${res.statusCode}`);
          console.error(`   Response: ${responseBody}`);
          reject(new Error(`Upload failed: ${res.statusCode}`));
        }
      });
    });

    req.on('error', (error) => {
      console.error(`❌ Error uploading ${fileName}:`, error.message);
      reject(error);
    });

    // Write file data
    req.write(fileBuffer);
    req.end();
  });
}

// Main upload process
async function main() {
  console.log('🚀 Starting R2 upload...\n');

  // Validate environment variables
  validateEnv();

  // Get version
  const version = getVersion();

  // Build file paths
  const projectRoot = join(__dirname, '../../../');
  const releaseDir = join(projectRoot, 'release');
  const files = [
    join(releaseDir, `cli-manager-${version}-x64.dmg`),
    join(releaseDir, `cli-manager-${version}-arm64.dmg`),
  ];

  // Validate files exist
  const missingFiles = files.filter(f => !existsSync(f));
  if (missingFiles.length > 0) {
    console.error('❌ Missing DMG files:');
    missingFiles.forEach(f => console.error(`   - ${f}`));
    process.exit(1);
  }

  console.log(`Bucket: ${config.bucketName}`);
  console.log(`Files: ${files.length}\n`);

  // Upload files
  for (const file of files) {
    try {
      await uploadFile(file, config);
    } catch (error) {
      console.error(`\n❌ Failed to upload ${basename(file)}:`, error.message);
      process.exit(1);
    }
  }

  console.log('\n🎉 All files uploaded successfully!');
}

main().catch(console.error);
