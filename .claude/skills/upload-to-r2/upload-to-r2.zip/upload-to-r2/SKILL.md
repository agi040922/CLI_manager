---
name: upload-to-r2
description: Upload release DMG files to Cloudflare R2 storage. This skill should be used when the user requests uploading DMG files to R2, after building a new release, or when updating download links for the website. Automatically detects version from package.json and uploads both arm64 and x64 DMG files using AWS S3-compatible API with proper authentication.
---

# Upload to R2

Upload CLI Manager release DMG files to Cloudflare R2 storage using secure environment-based credentials.

## When to Use This Skill

Use this skill when:
- The user requests uploading DMG files to R2 storage
- A new release has been built and needs to be distributed
- Updating download links for the website requires new file uploads
- The user mentions "R2", "upload release", or "publish DMG files"

## Prerequisites

### Environment Variables

Before using this skill, ensure the following environment variables are set. Never hardcode credentials in the codebase.

Required variables:
- `R2_ACCOUNT_ID`: Cloudflare account ID (from R2 dashboard URL)
- `R2_ACCESS_KEY_ID`: R2 API token access key
- `R2_SECRET_ACCESS_KEY`: R2 API token secret key
- `R2_BUCKET_NAME`: Target R2 bucket name (e.g., "solhun-downloads")

To set these variables, add them to the user's shell configuration (~/.zshrc or ~/.bashrc):

```bash
export R2_ACCOUNT_ID="your-account-id"
export R2_ACCESS_KEY_ID="your-access-key-id"
export R2_SECRET_ACCESS_KEY="your-secret-access-key"
export R2_BUCKET_NAME="your-bucket-name"
```

### Required Files

The skill expects DMG files to exist in the `release/` directory:
- `cli-manager-{version}-x64.dmg`
- `cli-manager-{version}-arm64.dmg`

The version is automatically detected from `package.json` or can be provided as a command-line argument.

## How to Use

### Basic Usage (Auto-detect version)

Execute the upload script from the project root:

```bash
node .claude/skills/upload-to-r2/scripts/upload-to-r2.js
```

The script will:
1. Validate all required environment variables are set
2. Read the version from `package.json`
3. Locate DMG files in `release/` directory
4. Upload both arm64 and x64 DMG files to R2
5. Display upload progress and final URLs

### Manual Version Override

To upload a specific version instead of auto-detecting:

```bash
node .claude/skills/upload-to-r2/scripts/upload-to-r2.js 1.2.0
```

## Implementation Details

### AWS Signature V4 Authentication

The script implements AWS Signature V4 authentication to securely upload files to Cloudflare R2's S3-compatible API. This ensures:
- Secure credential transmission
- Request integrity verification
- Protection against replay attacks

### Upload Process

For each DMG file:
1. Calculate file size and SHA-256 hash
2. Generate AWS Signature V4 authorization header
3. Send HTTPS PUT request with file data
4. Verify successful upload (HTTP 200 response)
5. Display the public R2 URL

### Error Handling

The script validates:
- All environment variables are set before starting
- DMG files exist in the expected location
- Upload responses are successful (HTTP 200)

If any validation fails, the script exits with a clear error message indicating what needs to be fixed.

## Expected Output

Successful upload example:

```
🚀 Starting R2 upload...

Auto-detected version from package.json: 1.1.1
Bucket: solhun-downloads
Files: 2

Uploading cli-manager-1.1.1-x64.dmg (117.70 MB)...
✅ cli-manager-1.1.1-x64.dmg uploaded successfully!
   URL: https://{account-id}.r2.cloudflarestorage.com/solhun-downloads/cli-manager-1.1.1-x64.dmg

Uploading cli-manager-1.1.1-arm64.dmg (111.15 MB)...
✅ cli-manager-1.1.1-arm64.dmg uploaded successfully!
   URL: https://{account-id}.r2.cloudflarestorage.com/solhun-downloads/cli-manager-1.1.1-arm64.dmg

🎉 All files uploaded successfully!
```

## Security Best Practices

1. **Never commit credentials**: Environment variables keep sensitive data out of the codebase
2. **Use minimal permissions**: R2 API tokens should have "Object Read & Write" permissions only
3. **Scope to specific bucket**: Restrict API token access to the target bucket only
4. **Rotate credentials regularly**: Update R2 API tokens periodically for security

## Related Workflows

After uploading to R2, typically:
1. Update download links in the website repository (solhun-web-page)
2. Verify files are accessible via public R2 URLs
3. Test download functionality on the production website

## Troubleshooting

### Missing environment variables

```
❌ Missing required environment variables:
   - R2_ACCESS_KEY_ID
   - R2_SECRET_ACCESS_KEY
```

**Solution**: Set the missing environment variables and reload your shell.

### Missing DMG files

```
❌ Missing DMG files:
   - /path/to/release/cli-manager-1.1.1-x64.dmg
```

**Solution**: Ensure the release build completed successfully and DMG files exist in `release/`.

### Upload failed with status 403

**Solution**: Verify R2 API credentials are correct and have proper permissions.

### Upload failed with status 404

**Solution**: Verify the R2 bucket name is correct and exists in your Cloudflare account.
